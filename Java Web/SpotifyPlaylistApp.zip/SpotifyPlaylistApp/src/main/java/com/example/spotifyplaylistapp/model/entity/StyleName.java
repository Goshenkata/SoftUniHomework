package com.example.spotifyplaylistapp.model.entity;

public enum StyleName {
    POP, ROCK, JAZZ
}
