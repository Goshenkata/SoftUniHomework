module.exports = {
    equal: function(a, b){
        return a == b
    },
}