package com.example.automapping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoMappingApplication.class, args);
	}

}
