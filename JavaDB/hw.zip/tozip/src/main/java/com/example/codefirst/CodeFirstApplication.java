package com.example.codefirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodeFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(CodeFirstApplication.class, args);
	}

}
