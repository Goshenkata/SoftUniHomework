package softuni.exam.models.entity;

public enum ApartmentType {
    TWO_ROOMS, THREE_ROOMS, FOUR_ROOMS
}
