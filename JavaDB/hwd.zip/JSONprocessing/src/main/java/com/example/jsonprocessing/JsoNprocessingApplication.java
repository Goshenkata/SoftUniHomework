package com.example.jsonprocessing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsoNprocessingApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsoNprocessingApplication.class, args);
    }

}
