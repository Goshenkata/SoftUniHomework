package com.example.jsonprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsoNprocessingApplicationTests {

    @Test
    void contextLoads() {
    }

}
