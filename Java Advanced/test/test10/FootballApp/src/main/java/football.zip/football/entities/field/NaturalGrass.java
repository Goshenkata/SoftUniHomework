package football.entities.field;

public class NaturalGrass extends BaseField{
    public NaturalGrass(String name) {
        super(name, 250);
    }
}
