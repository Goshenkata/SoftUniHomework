package football.entities.field;

import football.entities.player.BasePlayer;

public class ArtificialTurf extends BaseField {

    public ArtificialTurf(String name) {
        super(name, 150);
    }
}
