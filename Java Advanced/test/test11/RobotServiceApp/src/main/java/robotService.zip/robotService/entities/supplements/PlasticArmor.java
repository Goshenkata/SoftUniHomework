package robotService.entities.supplements;

public class PlasticArmor extends BaseSupplement{
    public PlasticArmor() {
        super(1, 10);
    }
}
